import csv
from pathlib import Path
from datetime import date, datetime
from typing import List

from bisect import bisect, bisect_left, insort_left

from werkzeug.security import generate_password_hash

from library.adapters.repository import AbstractRepository, RepositoryException
from library.domain.model import Book, User, Author, Publisher
from library.adapters.jsondatareader import BooksJSONReader


class MemoryRepository(AbstractRepository):
    # Articles ordered by date, not id. id is assumed unique.

    def __init__(self):
        self.__books = list()
        self.__books_index = dict()
        self.__users = list()

    def add_user(self, user: User):
        self.__users.append(user)

    def get_user(self, user_name) -> User:
        return next((user for user in self.__users if user.user_name == user_name), None)

    def add_book(self, book: Book):
        insort_left(self.__books, book)
        self.__books_index[book.book_id] = book

    def get_all_books(self):
        return self.__books

    def get_book(self, id: int) -> Book:
        book = None

        try:
            book = self.__books_index[id]
        except KeyError:
            pass

        return book

    def get_book_by_id(self, id: int) -> List[Book]:
        target_book = Book(book_id=id, book_title=None)
        matching_books = list()

        try:
            index = self.book_index(target_book)
            for book in self.__books[index:None]:
                if book.book_id == id:
                    matching_books.append(book)
                else:
                    break
        except ValueError:
            pass

        return matching_books

    def get_number_of_books(self):
        return len(self.__books)

    def get_first_book(self):
        book = None
        if len(self.__books) > 0:
            book = self.__books[0]
        return book

    def get_last_book(self):
        book = None
        if len(self.__books) > 0:
            book = self.__books[-1]
        return book

    def get_books_by_id(self, id_list):
        existing_ids = [id for id in id_list if id in self.__books_index]

        books = [self.__books_index[id] for id in existing_ids]
        return books

    def get_id_of_previous_book(self, book: Book):
        previous_id = None

        try:
            index = self.book_index(book)
            for stored_book in reversed(self.__books[0:index]):
                if stored_book.book_id < book.book_id:
                    previous_id = stored_book.book_id
                    break
        except ValueError:
            pass

        return previous_id

    def get_id_of_next_book(self, book: Book):
        next_id = None

        try:
            index = self.book_index(book)
            for stored_book in self.__books[index + 1: len(self.__books)]:
                if stored_book.book_id > book.book_id:
                    next_id = stored_book.book_id
                    break
        except ValueError:
            pass

        return next_id

    def book_index(self, book: Book):
        index = bisect_left(self.__books, book)
        if index != len(self.__books) and self.__books[index].book_id == book.book_id:
            return index
        raise ValueError





    def get_books_by_title(self, title: str):
        return self.__books

    def get_books_by_author(self, author: str):
        return self.__books

    def get_books_by_publisher(self, publisher: str):
        return self.__books


def load_books(data_path: Path, repo: MemoryRepository):
    books_filename = str(data_path / "comic_books_excerpt.json")
    authors_filename = str(data_path / "book_authors_excerpt.json")
    reader = BooksJSONReader(books_filename, authors_filename)
    reader.read_json_files()
    for book in reader.dataset_of_books:
        repo.add_book(book)

def populate(data_path: Path, repo: MemoryRepository):
    load_books(data_path, repo)