from typing import List, Iterable

from library.adapters.repository import AbstractRepository
from library.domain.model import Book, Author, Publisher


class NonExistentArticleException(Exception):
    pass


class UnknownUserException(Exception):
    pass

def get_book(id: int, repo: AbstractRepository):
    book = repo.get_book(id)

    if book is None:
        raise NonExistentArticleException

    return book_to_dict(book)

def get_first_book(repo: AbstractRepository):

    book = repo.get_first_book()

    return book_to_dict(book)

def get_last_book(repo: AbstractRepository):

    book = repo.get_last_book()

    return book_to_dict(book)



def get_book_by_id(id, repo: AbstractRepository):
    books = repo.get_book_by_id(id=id)
    books_dto = list()
    prev_id = next_id = None

    if len(books) > 0:
        prev_id = repo.get_id_of_previous_book(books[0])
        next_id = repo.get_id_of_next_book(books[0])

        books_dto = books_to_dict(books)

    return books_dto, prev_id, next_id

def get_books_by_id(id_list, repo: AbstractRepository):
    books = repo.get_books_by_id(id_list)
    books_as_dict = books_to_dict(books)
    return books_as_dict

def book_to_dict(book: Book):
    book_dict = {
        'book_id': book.book_id,
        'title': book.title,
        'description': book.description,
        'publisher': book.publisher,
        'authors': book.authors,
        'release_year': book.release_year,
        'ebook': book.ebook,
        'num_pages': book.num_pages
    }
    return book_dict

def books_to_dict(books: Iterable[Book]):
    return [book_to_dict(book) for book in books]

def dict_to_book(dict):
    book = Book(dict.book_id, dict.title)
    book.description = dict.description
    return book