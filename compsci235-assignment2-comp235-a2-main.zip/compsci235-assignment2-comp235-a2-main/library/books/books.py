from flask import Blueprint, request, render_template, redirect, url_for, session

from flask_wtf import FlaskForm
from wtforms import TextAreaField, HiddenField, SubmitField
from wtforms.validators import DataRequired, Length, ValidationError

import library.adapters.repository as repo
import library.books.services as services

from library.authentication.authentication import login_required

books_blueprint = Blueprint('books_bp', __name__)

@books_blueprint.route('/books', methods=['GET'])
def get_all_books():

    books = repo.repo_instance.get_all_books()

    return render_template('books.html', books=books)

@books_blueprint.route('/book_by_id')
def book_by_id():
    target_id = request.args.get('book_id')

    first_book = services.get_first_book(repo.repo_instance)
    last_book = services.get_last_book(repo.repo_instance)

    if target_id is None:
        target_id = first_book['book_id']

    books, previous_id, next_id = services.get_book_by_id(target_id, repo.repo_instance)

    first_book_url = None
    last_book_url = None
    next_book_url = None
    prev_book_url = None

    if len(books) > 0:
        if previous_id is not None:
            prev_book_url = url_for('books_bp.book_by_id', id=previous_id)
            first_book_url = url_for('books_bp.book_by_id', id=first_book['book_id'])

        if next_id is not None:
            next_book_url = url_for('books_bp.book_by_id', id=next_id)
            last_book_url = url_for('books_bp.book_by_id', id=last_book['book_id'])

        return render_template(
            'book_id.html',
            books=books,
            first_book_url=first_book_url,
            last_book_url = last_book_url,
            next_book_url = next_book_url,
            prev_book_url = prev_book_url
        )

    return redirect(url_for('home_bp.home'))



